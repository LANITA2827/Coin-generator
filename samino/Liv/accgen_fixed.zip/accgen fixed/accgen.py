from hmac import new
from os import urandom
from hashlib import sha1
from pyfiglet import figlet_format
from base64 import b64decode
from io import BytesIO
import names
from hashlib import sha1
import names
import random
import hmac
import platform,socket,re,uuid 
import base64
import hmac
import time
import json
from hashlib import sha1
import secmail
import random
import platform,socket,re,uuid
import json
import requests
from time import sleep
from bs4 import BeautifulSoup
from time import time as timestamp
import json
from os import path
from colored import fg, bg, attr
from pyfiglet import Figlet
import hashlib
import os
import aminofix as amino
password="" # Coloque a senha que quer aqui
print("\t\n accgen | fixed and translated by Dogaix\n")

client=amino.Client()

def sig(data):
        #at=json.dumps(data)
        key='fbf98eb3a07a9042ee5593b10ce9f3286a69d4e2'
        mac = hmac.new(bytes.fromhex(key), data.encode("utf-8"), sha1)
        digest = bytes.fromhex("32") + mac.digest()
        return base64.b64encode(digest).decode("utf-8")


def device(id: bytes = None) -> str:
    PREFIX = '19'
    DEVKEY = 'e7309ecc0953c6fa60005b2765f99dbbc965c8e9'
    info = bytes.fromhex(PREFIX) + (id or os.urandom(20))
    return (info + hmac.new(bytes.fromhex(DEVKEY), info, hashlib.sha1).digest()).hex().upper()


 
def gen_email():
    mail = secmail.SecMail()
    email = mail.generate_email()
    return email
    


def get_message(email):
                try:
                    sleep(4)
                    f=email
                    mail = secmail.SecMail()
                    inbox = mail.get_messages(f)
                    for Id in inbox.id:
                        msg = mail.read_message(email=f, id=Id).htmlBody
                        bs = BeautifulSoup(msg, 'html.parser')
                        images = bs.find_all('a')[0]
                        url = (images['href']+'\n')
                        if url is not None:
                         print(url)
                         return url
                         #wget.download(url=url,out="code.png")
                except:
                    pass

def fancy_name():
    nm=''
    for i in names.get_first_name():
        nm=nm+i
    return nm


def generation_process(count: int):
    for i in range(count):
        deviceid=device()
        values=gen_email()
        email=values
        nick = str(fancy_name())
        req=client.request_verify_code(email=email, resetPassword=False)
        get_message(values)
        vcode=input("Coloque o código aqui:  ")
        client.register(nickname=nick, email=email, password=password,deviceId=deviceid,verificationCode=vcode)
        print(f"-- Gerando {count} contas...")
        with open('accounts.json', 'a') as x:
            acc = f'\n{{\n"email": "{email}", \n"password":"{password}",\n"device": "{deviceid}"\n}},'
            x.write(acc)
        
      
generation_process(count=int(input("Quantas contas gerar: ")))
